package executavel2;
import java.util.Scanner;

import informacao2.exercico2;

public class Main {
	
	public static void main(String[] args) {
int a, p;
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Por favor insira o tamanho da Altura: ");
		a = sc.nextInt();
		System.out.println("Largura: ");
		p = sc.nextInt();
		
		exercico2 calculo = new exercico2(a, p);
		
		System.out.println(calculo);
		
		
		sc.close();
	}

}
