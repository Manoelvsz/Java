package Executavel4;

import java.util.Scanner;
import entidade4.info;

public class Main {

	public static void main(String[] args) {
		String nome;
		double nota1, nota2, nota3;
		Scanner sc = new Scanner (System.in);
		
		System.out.println("Insira o nome do aluno: ");
        nome=sc.nextLine();
		do {
        System.out.println("Insira a nota1: ");
		System.out.println("Nota maxima 30 ");
		nota1=sc.nextDouble();
		} while(nota1 > 30);
		do {
		System.out.println("Insira a nota2: ");
		System.out.println("Nota maxima 35 ");
		nota2=sc.nextDouble();
		} while(nota2 > 35);
		do {
		System.out.println("Insira a nota3: ");
		System.out.println("Nota maxima 35 ");
		nota3=sc.nextDouble();
		} while(nota3 > 35);
		
		info aluno = new info(nome, nota1, nota2, nota3);
		System.out.println(aluno);
		
	}

}
