package informacao2;

public class exercico2 {

	int a, p; //P=Largura

	public exercico2(int a, int p) {
		super();
		this.a = a;
		this.p = p;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getP() {
		return p;
	}

	public void setP(int p) {
		this.p = p;
	}

	
	public int calculoA() {
		return a * p;
	}
    public int CalculoP() {
    	return  (a * 2) + (p *2);
    }
	public double calculoD() {
		return Math.sqrt((a*a) + (p*p));
	}
	
	
}



/*
 * 
Fazer um programa para ler os valores da largura e altura de um retângulo. Em seguida,
mostrar na tela o valor de sua área, perímetro e diagonal.
Exemplo de Interação:
Informe a largura e altura do retângulo:
3,00
4,00
Area = 12,00
Perímetro = 14,00
Diagonal = 5,00

*/




